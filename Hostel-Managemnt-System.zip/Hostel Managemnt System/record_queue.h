
#pragma once


#include<iostream>
#include"queue.h"
#include"Student.h"
class record_q
{

public:
     queue_l r;


    void menu();
    void enter_record();
    void search_record();
    void delete_record();



};


