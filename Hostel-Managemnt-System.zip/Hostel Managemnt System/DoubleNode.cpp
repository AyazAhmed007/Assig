#include<iostream>
#include"DoubleNode.h"
using namespace std;
template <class T>
 Node_d<T>::Node_d()
 {
     N=NULL;
     P=NULL;
 }
template <class T>
Node_d<T>::Node_d(T D)
{
    data=D;
    N=NULL;
    P=NULL;
}
template<class T>
Node_d<T>* Node_d<T>::GetPre()
{
    return P;
}
template<class T>
void Node_d<T>::SetPre(Node_d<T> *ptr)
{
    P=ptr;
}
template <class T>
T Node_d<T>:: GetData()
{
    return data;
}
template <class T>
void Node_d<T>::SetPtr(Node_d<T> *ptr)
{
    N=ptr;
}
template <class T>
Node_d<T>* Node_d<T>::GetPtr()
{
    return N;
}
template <class T>
Node_d<T>::~Node_d()
{

}

