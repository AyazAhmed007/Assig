
#include<iostream>
#include"DoubleNode.cpp"
#include"Double_LL.h"

using namespace std;
template<class T>
DLList<T>::DLList()
{
    head=NULL;
}
template<class T>
void DLList<T>::AddToHead(T data)
{
        Node_d<T>* ptr;
        ptr=new Node_d<T> (data);
        if (head==NULL)
            head =ptr;
        else
            {
                ptr->SetPtr(head);
                head=ptr;
                head->GetPtr()->SetPre(head);
            }
}
template<class T>
void DLList<T>::AddToTail(T data)
{
    Node_d<T> *p = new Node_d<T>(data);
		if (head == NULL)
		{
			head = p;
		}

		Node_d<T> *temp = head;
	while (temp->GetPtr() != NULL)
	{
	    temp=temp->GetPtr();
	}
	temp->SetPtr(p);
	p->SetPre(temp);
	p->SetPtr(NULL);
}

template<class T>
Node_d<T>* DLList<T>::GetHead()
{
    return head;
}
template<class T>
Node_d<T>* DLList<T>::Search(T key)
{
if (head == NULL)
	{
		cout << "\nLinkDLList IS EMPTY\n";
		return NULL;
	}
	else
		{Node_d<T>*temp =head;
 		while (temp != NULL)
		{
			if (temp->GetData() == key)
			{
				return temp;
			}
			temp = temp->GetPtr();
		}
		return NULL;
	}
}
template<class T>
void DLList<T>::InsertAfter(T data,T key)
{
if (head = NULL)
	{
		cout << "\nLinkDLList IS EMPTY\n";
	}
	else
		{
            Node_d<T>* temp = new Node_d<T>(data);
            Node_d<T>* p=Search(data);
            if (p==NULL)
            {
                cout<<"\n Invalid data\n";
            }
            else
                {
                    temp->SetPtr(p->GetPtr());
                    p->SetPtr(temp);
                    temp->SetPre(p);
                    p->GetPtr()->SetPre(temp);
                }
        }
}
template<class T>
void DLList<T>::DeleteAtN(Node_d<T>* t)
{

    Node_d<T>* temp=t;

    temp->GetPre()->SetPtr(temp->GetPtr());
    temp->GetPtr()->SetPre(temp->GetPre());
    delete temp;

}
template<class T>
void DLList<T>::AddAtN(T key, int N)
{
    int count =0;
    Node_d<T>* temp=new Node_d<T>(key);
    Node_d<T>* p=head;
    while(count!=N-1)
    {
        p=p->GetPtr();
    }
    temp->SetPtr(p->GetPtr());
    p->SetPtr(temp);
                    temp->SetPre(p);
                    p->GetPtr()->SetPre(temp);

}
template<class T>
void DLList<T>::DeleteAtHead()
{
    if (head == NULL)
	{
		cout << "\nLinkDLList IS EMPTY\n";
	}
	else
		{
                Node_d<T> *temp=head;
                head=head->GetPtr();
                head->SetPre(NULL);
                delete temp;
        }
}
template<class T>
void DLList<T>::DeleteAtTail()
{
    if (head == NULL)
	{
		cout << "\nLinkDLList IS EMPTY\n";
	}
	else
	{
		Node_d<T>*temp = head;
		while (temp->GetPtr() != NULL)
		{
			temp = temp->GetPtr();
		}
		temp->GetPre()->SetPtr(NULL);
		delete temp;
		cout << "\nDELETED :D\n";
	}
}
template<class T>
void DLList<T>::DisplayMenu()
{
   {
    cout<<"\nEnter 1 to Add To Head\n";
    cout<<"Enter 2 to Add To Tail\n";
    cout<<"Enter 3 to Insert After\n";
    cout<<"Enter 4 to Insert At N\n";
    cout<<"Enter 5 to Search\n";
    cout<<"Enter 6 to Delete From Head\n";
    cout<<"Enter 7 to Delete From Tail\n";
    cout<<"Enter 8 to Delete AT N\n";
    cout<<"Enter 9 for Print DLList\n";
    cout<<"Enter 0 to Exit \n";
}
}
template<class T>
void DLList<T>::PrintDLList()
{
    if(head==NULL)
    {
        cout<<"LINKDLList IS EMPTY\n";
    }
    else
    {
        Node_d<T> *temp=head;
        while(temp->GetPtr()!=NULL)
        {
            cout<<temp->GetData()<<" ";
            temp=temp->GetPtr();
        }
       // cout<<temp->GetData()<<"\n";
    }
}
template<class T>
DLList<T>::~DLList()
{

}
