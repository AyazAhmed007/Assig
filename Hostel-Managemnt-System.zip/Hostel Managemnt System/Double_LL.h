
#pragma once
#include<iostream>
#include"DoubleNode.h"
template<class T>
class DLList{
public:
    Node_d<T> *head;

    DLList();
    Node_d<T>* GetHead();
    void AddToHead(T data);
    void AddToTail(T data);
    void InsertAfter(T data, T key);
    void AddAtN(T data ,int N );
    Node_d<T> *Search(T key);
    void DeleteAtHead();
    void DeleteAtTail();
    void DeleteAtN(Node_d<T>* t);
    void DisplayMenu();
    void PrintDLList();
    ~DLList();
};


