#pragma once
#include"node.h"
#include"Student.h"
class queue_l
{
    public:
     Node<Student>* head;

     int size;


     queue_l();
     void  enqueue_l(Node<Student> value);
     void  dequeue_l();

     void display_size();
     void display();
     bool is_empty();
};

