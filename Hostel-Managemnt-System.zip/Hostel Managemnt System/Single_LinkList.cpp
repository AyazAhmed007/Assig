
#include <iostream>
#include "Single_LinkList.h"

using namespace std;

template<class T>
Node<T>::Node()
{
    data = 0;
    Next = NULL;
}

template<class T>
Node<T>::Node(T val)
{
    data = val;
    Next = NULL;
}

template<class T>
T Node<T>::GetData()
{
    return data;
}

template<class T>
Node<T> * Node<T>::GetNext()
{
    return Next;
}

template<class T>
void Node<T>::SetData(T val)
{
    data = val;
}

template<class T>
void Node<T>::SetNext(Node * ptr)
{
    Next = ptr;

}

template<class T>
SLL<T>::SLL()
{
    head = NULL;
}

template<class T>
void SLL<T>::InsertAtHead(T val)
{
    Node<T> * ptr = new Node<T>(val);
    ptr->SetNext(head);
    head = ptr;
}

template<class T>
void SLL<T>::InsertAtTail(T val)
{
    Node<T> * ptr = new Node<T>(val);
    if(head == NULL)
        head = ptr;
    else
    {
        Node<T> * temp = head;
        while(temp->GetNext() != NULL)
            temp = temp->GetNext();
        temp->SetNext(ptr);
    }
}

template<class T>
void SLL<T>::InsertAfter(T val, T key)
{
    if (head != NULL)
    {
        Node<T> * temp = Search(key);
        if (temp != NULL)
        {
            Node<T> * ptr = new Node<T>(val);
            ptr->SetNext(temp->GetNext());
            temp->SetNext(ptr);
        }
        else
            cerr << "\n\tKey Not Found!\n";
    }
}

template<class T>
void SLL<T>::InsertBefore(T val, T key)
{
    if (head != NULL)
    {
        Node<T> * temp = Search2(key);
        if (temp != NULL)
        {
            Node<T> * ptr = new Node<T>(val);
            ptr->SetNext(temp->GetNext());
            temp->SetNext(ptr);
        }
        else
            cerr << "\n\tKey Not Found!\n";
    }
}
template<class T>
void SLL<T>::delete_after_node(Node<T>* x)
{   Node<T>* temp=x->Next;
    x->Next=temp->Next;
    delete temp;




}

template<class T>
Node<T> * SLL<T>::Search(T key)
{
    Node<T> * temp = head;
    while (temp != NULL)
    {
        if(temp->GetData() == key)
            return temp;
        else
            temp = temp->GetNext();
    }
    return NULL;
}

template<class T>
Node<T> * SLL<T>::Search2(T key)
{
    Node<T> * temp = head;
    Node<T> * temp2 = head;
    while (temp != NULL)
    {
        if(temp->GetData() == key)
            return temp2;
        else
        {
            temp2 = temp;
            temp = temp->GetNext();
        }
    }
    return NULL;
}

template<class T>
void SLL<T>::Print()
{
    Node<T> * ptr = head;
    cout << "\nList: ";
    for(int i = 0; ptr != NULL; i++)
    {
        cout << ptr->GetData() << " ";
        ptr = ptr->GetNext();
    }
}

template class SLL <int>;
template class Node<int>;
