
#include <iostream>
#include "node.h"

using namespace std;

template<class T>
Node<T>::Node()
{
    data = 0;
    Next = NULL;
}

template<class T>
Node<T>::Node(T val)
{
    data = val;
    Next = NULL;
}

template<class T>
T Node<T>::GetData()
{
    return data;
}

template<class T>
Node<T> * Node<T>::GetNext()
{
    return Next;
}

template<class T>
void Node<T>::SetData(T val)
{
    data = val;
}

template<class T>
void Node<T>::SetNext(Node * ptr)
{
    Next = ptr;

}

