#pragma once


template <class T>
class Node
{
public:
    Node();
    Node(T);
    T GetData();
    Node * GetNext();
    void SetData(T);
    void SetNext(Node *);

    T data;
    Node<T> * Next;
};

