#pragma once


#include"node.h"
using namespace std;
template<class T>
class SLL
{
public:
    SLL();
    Node<T> * GetHead();
    void SetHead(Node<T> *);
    void InsertAtHead(T);
    void InsertAtTail(T);
    void InsertAfter(T, T);
    void InsertBefore(T, T);
    Node<T> * Search(T);
    Node<T> * Search2(T);
    void delete_after_node(Node<T>* x);

    void Print();
    Node<T> * head;
};

