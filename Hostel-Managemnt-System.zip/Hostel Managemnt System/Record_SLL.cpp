
#include<iostream>
#include"Student.h"
//#include"Single_LinkList.h"
#include"Record_SLL.h"
using namespace std;





void Record_SLL::menu(){
     Student s;
     Student as("ali","hhh",20,222,112);
     Student ss("haider","fff",21,422,111);
     Student ds("usman","ddd",24,272,1121);
     Student fs("bashir","sss",22,722,115);
     Student gs("nazeer","aaa",23,5522,181);
     obj.InsertAtHead(as);
     obj.InsertAtHead(ss);
     obj.InsertAtHead(ds);
     obj.InsertAtHead(fs);
     obj.InsertAtHead(gs);

    int l = 0;
    int opt=0;
  cout << "\tMENU:\n";
        cout << "Enter 1 to Enter in the recored\n";
        cout << "Enter 2 to view  the recored \n";
        cout << "Enter 3 to search in the recored\n";
        cout << "Enter 4 to delete in the rerocd\n";


        cout << "Enter 0 to Exit\n";
        cout << "Option: ";
        cin >> opt;
    while(l == 0)
    {



        switch(opt)
        {
        case 1:
            cout << "Enter Details: \n";

            s.set_data();
            cout<<"done1";
            obj.InsertAtHead(s);
            cout<<"done";
            break;
        case 2:
            obj.Print();
            break;
        case 3:
             this->search_L();
            break;
        case 4:
             this->delete_record();
            break;
        case 5:
            break;
        case 6:

            break;
        case 0:
           // exit(0);
           l=1;
            break;
        default:
            cerr << "Wrong Option Entered!\n";
            break;
        }
        cout << "\n\n";
         cout << "\tMENU:\n";
        cout << "Enter 1 to Enter in the recored\n";
        cout << "Enter 2 to view  the recored \n";
        cout << "Enter 3 to search in the recored\n";
        cout << "Enter 4 to delete in the rerocd\n";


        cout << "Enter 0 to Exit\n";
        cout << "Option: ";
        cin >> opt;

    }
}

void Record_SLL::search_L()
{
    cout<<"Please enter the name \n";
    string asd;
    cin>>asd;
    Node<Student>* cursor=obj.head;
    while(cursor!=NULL)
    {
        if(cursor->data.name==asd)
        {
            cout<<cursor->data;
        }
        cursor=cursor->Next;
    }
}


Node<Student>*& Record_SLL::search_record1(string zxa)
{
    Node<Student>* cursor=obj.head;
    Node<Student>* prv=NULL;
    int i=0;
   while(cursor!=NULL)
   {
       if ((cursor->data.name)==zxa)
        {
             cout<<i<<" :\n";
            cout<<cursor->data<<endl;
            //i++;
            return prv;
       }
       prv=cursor;
        cursor=cursor->Next;

    }
}

void Record_SLL::delete_record()
{
    cout<<"Please enter the name of student you Want to delete\n";
    string zxc;
    cin>>zxc;
    obj.delete_after_node(this->search_record1(zxc))   ;
}

