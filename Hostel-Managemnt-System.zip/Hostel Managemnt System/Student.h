#pragma once

using namespace std;
#include<iostream>
class Student{
public:
    string name,address;
    int age,id,number;
   Student();
     friend ostream& operator<<(ostream& os, const Student& St)
     {
    os <<"************************"<<endl
    <<"Name: "<< St.name<<endl
     <<"Address: "<<St.address <<endl
     <<"Id: " <<St.id<<endl
     <<"Age: " <<St.age<<endl
     <<"Num: " <<St.number<<endl;
    return os;


}
   void set_data();
   Student(string ,string ,int ,int ,int );
};
//    ostream& operator<<(ostream& os, const Student& St)



