
#pragma once


#include<iostream>
#include"stack.cpp"
#include"Student.h"
class record_stack
{

public:
     stack_ll r;

    void menu();
    void enter_record();

    Node<Student>*& search_record1();
    void delete_record();

    void print_record();


};

