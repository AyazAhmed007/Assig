#pragma once
#include<iostream>
template<class T>
class Node_d{
    public:
    Node_d<T> *N;
    Node_d<T> *P;
    T data;
public:
    Node_d();
    Node_d(T D);
    T GetData();
    Node_d<T>* GetPtr();
    Node_d<T>* GetPre();
    void SetPre(Node_d<T> *ptr);
    void SetPtr(Node_d<T> *ptr);
    ~Node_d();
    };

