#pragma once

#include<iostream>
#include"Double_LL.cpp"
#include"Student.h"
class record_dll
{

public:
     DLList<Student> obj;


    void menu();
    void enter_record();
    void search_record();
    Node_d<Student>*& search_record1(string);
    void delete_record();

    void print_record();


};
