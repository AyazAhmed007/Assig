#include"queue.h"
#include<iostream>
using namespace std;
queue_l::queue_l()
{
    size=0;
    head=NULL;
}
void queue_l::enqueue_l(Node<Student> value)
{
    Node<Student>* inserthead;
    if (is_empty())
    {

    inserthead=new Node<Student>(value);
    head=inserthead;
    size++;



    }
    else
    {
        inserthead=new Node<Student>(value);
        inserthead->Next=head;
        head=inserthead;
            size++;

    }


}
bool queue_l::is_empty()
{
    if (size==0)
    { //  cout<<"Yes\n";
        return 1;
    }
    else
    { // cout<<"no\n";
        return 0;

}
}
void queue_l::dequeue_l()
{
    if(is_empty())
    cout<<"Error_empty\n";
    else
    {
      Node<Student> *cursor=head;
      while(cursor->Next->Next!=NULL)
      {
          cursor=cursor->Next;
      }

      delete cursor->Next;
       cursor->Next=NULL;

    }
}



void queue_l::display()
{
    if(head!=NULL)
    {


    Node<Student> *ptr;
       cout<<endl<<"-----------------------------------------------------------"<<endl;
       cout<<"                     THE LIST                    "<<endl;
       cout<<"-----------------------------------------------------------"<<endl;

	   for(ptr = head;;ptr = ptr->Next)
		{
		    cout<<ptr->data<<"    \n\n    ";
		    if(ptr->Next==NULL)
                break;
		}
		       cout<<endl<<"-----------------------------------------------------------"<<endl;
       cout<<"-----------------------------------------------------------"<<endl;

	cout<<endl<<endl<<endl;

    }

    else{
        cout<<"list not present"<<endl;
    }
}


void queue_l::display_size()
{
    cout<<size<<endl;
}




