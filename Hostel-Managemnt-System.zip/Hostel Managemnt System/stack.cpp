
#include"Node.h"
#include"Student.h"
class stack_ll
{
public:
Node<Student> *Head_ptr;
int size;

//constructor
stack_ll()
{
Head_ptr = NULL;
size=0;
}
//print list
void print_list()
{
    if(Head_ptr!=NULL)
    {


    Node<Student> *ptr;
       cout<<endl<<"-----------------------------------------------------------"<<endl;
       cout<<"                     THE LIST                    "<<endl;
       cout<<"-----------------------------------------------------------"<<endl;

	   for(ptr = Head_ptr;;ptr = ptr->Next)
		{
		    cout<<ptr->data<<"    ,    \n\n";
		    if(ptr->Next==NULL)
                break;
		}
		       cout<<endl<<"-----------------------------------------------------------"<<endl;
       cout<<"-----------------------------------------------------------"<<endl;

	cout<<endl<<endl<<endl;

    }

    else{
        cout<<"list not present"<<endl;
    }

}

void Empty()
{
    if (size==0)
        cout<<"Yes"<<endl;
    else cout<<"No"<<endl;
}
//inert at head
void Push(Node<Student> v)
{
	Node<Student> *ptr = new Node<Student>(v);
	ptr->Next=Head_ptr;
	Head_ptr=ptr;
	size++;

}

Node<Student> Pop()
{
    Node<Student> x=Head_ptr->data;
    Node<Student>* temp=Head_ptr;
    Head_ptr=Head_ptr->Next;
    delete temp;
    size--;
    return x;

}
//inest at the end of the list


void Size()
{
    cout<<size<<endl;
}
Node<Student>* key_search(string key)
	{
		Node<Student> *temp;
		temp = Head_ptr;
		bool check=1;
		while(check)
		{
		     if(temp->data.name==key)
		         {
		             return temp;
                 }
                 else if(temp->Next==NULL)
                    break;
		     else
		        {
			          temp=temp->Next;
		        }

		}

		return NULL;
	}







};


























