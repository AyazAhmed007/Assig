#include<iostream>
//#include"Student.h"
#include"Double_LL.h"
#include"Record_DLL.h"
using namespace std;





void record_dll::menu(){
     Student s;
     Student as("ali","hhh",20,222,112);
     Student ss("haider","fff",21,422,111);
     Student ds("usman","ddd",24,272,1121);
     Student fs("bashir","sss",22,722,115);
     Student gs("nazeer","aaa",23,5522,181);
     obj.AddToHead(as);
     obj.AddToHead(ss);
     obj.AddToHead(ds);
     obj.AddToHead(fs);
     obj.AddToHead(gs);

    int l = 0;
    int opt=0;
  cout << "\tMENU:\n";
        cout << "Enter 1 to Enter in the recored\n";
        cout << "Enter 2 to view  the recored \n";
        cout << "Enter 3 to search in the recored\n";
        cout << "Enter 4 to delete in the rerocd\n";


        cout << "Enter 0 to Exit\n";
        cout << "Option: ";
        cin >> opt;
    while(l == 0)
    {



        switch(opt)
        {
        case 1:
            cout << "Enter Details: \n";

            s.set_data();
            cout<<"done1";
            obj.AddToHead(s);
            cout<<"done";
            break;
        case 2:
            obj.PrintDLList();
            break;
        case 3:
             this->search_record();
            break;
        case 4:
             this->delete_record();
            break;
        case 5:
            break;
        case 6:

            break;
        case 0:
           // exit(0);
           l=1;
            break;
        default:
            cerr << "Wrong Option Entered!\n";
            break;
        }
        cout << "\n\n";
         cout << "\tMENU:\n";
        cout << "Enter 1 to Enter in the recored\n";
        cout << "Enter 2 to view  the recored \n";
        cout << "Enter 3 to search in the recored\n";
        cout << "Enter 4 to delete in the rerocd\n";


        cout << "Enter 0 to Exit\n";
        cout << "Option: ";
        cin >> opt;

    }
}

void record_dll::search_record()
{
    cout<<"Please enter the name \n";
    string asd;
    cin>>asd;
    Node_d<Student>* cursor=obj.head;
    while(cursor!=NULL)
    {
        if(cursor->data.name==asd)
        {
            cout<<cursor->data;
        }
        cursor=cursor->N;
    }
}




void record_dll::delete_record()
{
    cout<<"Please enter the name of student you Want to delete\n";
    string zxc;
    cin>>zxc;
    obj.DeleteAtN(this->search_record1(zxc));

}
Node_d<Student>*& record_dll::search_record1(string zxa)
{
    Node_d<Student>* cursor=obj.head;

    int i=0;
   while(cursor!=NULL)
   {
       if ((cursor->data.name)==zxa)
        {
             cout<<i<<" :\n";
            cout<<cursor->data<<endl;
            //i++;
            return cursor;
       }

        cursor=cursor->N;

    }
}


