#include<iostream>
#include"reccord_stack.h"
#include<strings.h>
using namespace std;

void record_stack::enter_record()
{
    Student a;
    a.set_data();
    r.Push(a);
    cout<<"done\n";

}

void record_stack::print_record()
{
    r.print_list();
}



Node<Student>*& record_stack::search_record1()
{    string zxa;
     cin>>zxa;
    Node<Student>* cursor=r.Head_ptr;
    Node<Student>* prv=NULL;
    int i=0;
   while(cursor!=NULL)
   {
       if ((cursor->data.name)==zxa)
        {
             cout<<i<<" :\n";
            cout<<cursor->data<<endl;
            //i++;
            return prv;
       }
       prv=cursor;
        cursor=cursor->Next;

    }
}

void record_stack::delete_record()
{

     r.Pop();
}



void record_stack::menu()
{
   Student s;
     Student as("ali","hhh",20,222,112);
     Student ss("haider","fff",21,422,111);
     Student ds("usman","ddd",24,272,1121);
     Student fs("bashir","sss",22,722,115);
     Student gs("nazeer","aaa",23,5522,181);
     r.Push(as);
     r.Push(ss);
     r.Push(ds);
     r.Push(fs);
     r.Push(gs);

    int l = 0;
    int opt=0;
  cout << "\tMENU:\n";
        cout << "Enter 1 to Enter in the recored\n";
        cout << "Enter 2 to view  the recored \n";
        cout << "Enter 3 to search in the recored\n";
        cout << "Enter 4 to delete in the rerocd\n";


        cout << "Enter 0 to Exit\n";
        cout << "Option: ";
        cin >> opt;
    while(l == 0)
    {



        switch(opt)
        {
        case 1:
            cout << "Enter Details: \n";

            s.set_data();
            cout<<"done1";
            r.Push(s);
            cout<<"done";
            break;
        case 2:
            r.print_list();
            break;
        case 3:
             this->search_record1();
            break;
        case 4:
             this->delete_record();
            break;
        case 5:
            break;
        case 6:

            break;
        case 0:
           // exit(0);
           l=1;
            break;
        default:
            cerr << "Wrong Option Entered!\n";
            break;
        }
        cout << "\n\n";
         cout << "\tMENU:\n";
        cout << "Enter 1 to Enter in the recored\n";
        cout << "Enter 2 to view  the recored \n";
        cout << "Enter 3 to search in the recored\n";
        cout << "Enter 4 to delete in the rerocd\n";


        cout << "Enter 0 to Exit\n";
        cout << "Option: ";
        cin >> opt;

    }
}


