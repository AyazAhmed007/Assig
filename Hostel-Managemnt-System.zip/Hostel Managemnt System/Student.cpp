#include<iostream>
#include"Student.h"
//#include"SLL.h"

Student::Student()
{
        name="";
        address="";
        age=0;
        number=0;
        id=0;
}

Student:: Student(string n,string add,int agr,int numbe,int i)
    {
        name=n;
        address=add;
        age=agr;
        number=numbe;
        id=i;
    }
void Student:: set_data(){
cout<<"###################"<<endl;
cout<<"NAme"<<endl;
cin>>name;
cout<<"Addres"<<endl;
cin>>address;
cout<<"Age"<<endl;
cin>>age;
cout<<"NMob Number"<<endl;
cin>>number;
cout<<"ID"<<endl;
cin>>id;
}
