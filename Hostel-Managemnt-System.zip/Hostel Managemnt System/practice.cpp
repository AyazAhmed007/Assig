
#include<iostream>

#include"Record_SLL.h"
#include"Record_DLL.h"
#include"record_queue.h"
#include"reccord_stack.h"

 using namespace std;

 int main()
 {

   Record_SLL a;
   record_dll d;
   record_q q;
   record_stack s;


    cout<<endl<<endl<<endl<<"*****************************************************"<<endl;
cout<<"       ***************************************       "<<endl;
cout<<"            ***************************              "<<endl;
cout<<"Press 1 for Single LinkList"<<endl;
cout<<"press 2 for Double LinkList"<<endl;
cout<<"press 3 for Queue"<<endl;
cout<<"press 4 for stack"<<endl;
cout<<"press 5 for BST"<<endl;


cout<<"*****************************************************"<<endl;
cout<<"       ***************************************       "<<endl;
cout<<"            ***************************              "<<endl<<endl<<endl;

  int x;

	 x=99;
	cin>>x;
	while(x!=0)

    {


switch(x)
{



case 1:

     a.menu();

     break;


case 2:
     d.menu();
    break;
case 3:
    q.menu();

	break;

case 4:
    s.menu();
    break;

case 5:
    cout<<"errr";
    break;
default:

    break;
    //end switch

}
cout<<endl<<endl<<endl<<"*****************************************************"<<endl;
cout<<"       ***************************************       "<<endl;
cout<<"            ***************************              "<<endl;
cout<<"Press 1 for Single LinkList"<<endl;
cout<<"press 2 for Double LinkList"<<endl;
cout<<"press 3 for stack"<<endl;
cout<<"press 4 for Queue"<<endl;
cout<<"press 5 for BST"<<endl;


cout<<"*****************************************************"<<endl;
cout<<"       ***************************************       "<<endl;
cout<<"            ***************************              "<<endl<<endl<<endl;
cin>>x;

    }   //end while


 }
