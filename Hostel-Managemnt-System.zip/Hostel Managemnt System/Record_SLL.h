#pragma once

#include<iostream>
#include"Student.h"
#include"Single_LinkList.cpp"
class Record_SLL{

public:
   // Record_SLL();
    SLL<Student> obj;
    void menu();
    void search_L();
    Node<Student>*& search_record1(string zxa);
    void delete_record();


};

